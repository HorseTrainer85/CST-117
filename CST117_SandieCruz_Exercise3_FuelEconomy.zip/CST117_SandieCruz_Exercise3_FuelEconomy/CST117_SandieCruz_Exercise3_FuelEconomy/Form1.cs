﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST117_SandieCruz_Exercise3_FuelEconomy
{
    public partial class FuelEconomyForm : Form
    {
        public FuelEconomyForm()
        {
            InitializeComponent();
        }
        private void MilesTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void GallonsTextbox_TextChanged(object sender, EventArgs e)
        {

        }
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double miles;   // To hold miles driven  
            double gallons; // To hold gallons used
            double mpg;     // To hold MPG

            // Validate the milesTextBox control.
            if (double.TryParse(MilesTextBox.Text, out miles))
            {
                // Validate the gallonsTextBox control.
                if (double.TryParse(GallonsTextbox.Text, out gallons))
                {
                    // Calculate MPG.
                    mpg = miles / gallons;

                    // Display the MPG in the mpgLabel control.
                    MPG_Label.Text = mpg.ToString();
                }              
            }          
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
