﻿namespace CST117_SandieCruz_Exercise3_FuelEconomy
{
    partial class FuelEconomyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MilesPromptLabel = new System.Windows.Forms.Label();
            this.GallonsPromptLabel = new System.Windows.Forms.Label();
            this.OutputDescriptionLabel = new System.Windows.Forms.Label();
            this.MilesTextBox = new System.Windows.Forms.TextBox();
            this.GallonsTextbox = new System.Windows.Forms.TextBox();
            this.MPG_Label = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MilesPromptLabel
            // 
            this.MilesPromptLabel.AutoSize = true;
            this.MilesPromptLabel.Location = new System.Drawing.Point(12, 19);
            this.MilesPromptLabel.Name = "MilesPromptLabel";
            this.MilesPromptLabel.Size = new System.Drawing.Size(161, 13);
            this.MilesPromptLabel.TabIndex = 0;
            this.MilesPromptLabel.Text = "Enter the number of miles driven:";
            // 
            // GallonsPromptLabel
            // 
            this.GallonsPromptLabel.AutoSize = true;
            this.GallonsPromptLabel.Location = new System.Drawing.Point(12, 45);
            this.GallonsPromptLabel.Name = "GallonsPromptLabel";
            this.GallonsPromptLabel.Size = new System.Drawing.Size(147, 13);
            this.GallonsPromptLabel.TabIndex = 1;
            this.GallonsPromptLabel.Text = "Enter the gallons of gas used:";
            // 
            // OutputDescriptionLabel
            // 
            this.OutputDescriptionLabel.AutoSize = true;
            this.OutputDescriptionLabel.Location = new System.Drawing.Point(12, 71);
            this.OutputDescriptionLabel.Name = "OutputDescriptionLabel";
            this.OutputDescriptionLabel.Size = new System.Drawing.Size(84, 13);
            this.OutputDescriptionLabel.TabIndex = 2;
            this.OutputDescriptionLabel.Text = "Your car\'s MPG:";
            // 
            // MilesTextBox
            // 
            this.MilesTextBox.Location = new System.Drawing.Point(179, 16);
            this.MilesTextBox.Name = "MilesTextBox";
            this.MilesTextBox.Size = new System.Drawing.Size(100, 20);
            this.MilesTextBox.TabIndex = 3;
            this.MilesTextBox.TextChanged += new System.EventHandler(this.MilesTextBox_TextChanged);
            // 
            // GallonsTextbox
            // 
            this.GallonsTextbox.Location = new System.Drawing.Point(179, 42);
            this.GallonsTextbox.Name = "GallonsTextbox";
            this.GallonsTextbox.Size = new System.Drawing.Size(100, 20);
            this.GallonsTextbox.TabIndex = 4;
            this.GallonsTextbox.TextChanged += new System.EventHandler(this.GallonsTextbox_TextChanged);
            // 
            // MPG_Label
            // 
            this.MPG_Label.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.MPG_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MPG_Label.Location = new System.Drawing.Point(179, 70);
            this.MPG_Label.Name = "MPG_Label";
            this.MPG_Label.Size = new System.Drawing.Size(100, 20);
            this.MPG_Label.TabIndex = 5;
            // 
            // CalculateButton
            // 
            this.CalculateButton.Location = new System.Drawing.Point(51, 108);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(75, 23);
            this.CalculateButton.TabIndex = 6;
            this.CalculateButton.Text = "Calculate MPG";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(151, 108);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // FuelEconomyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.MPG_Label);
            this.Controls.Add(this.GallonsTextbox);
            this.Controls.Add(this.MilesTextBox);
            this.Controls.Add(this.OutputDescriptionLabel);
            this.Controls.Add(this.GallonsPromptLabel);
            this.Controls.Add(this.MilesPromptLabel);
            this.Name = "FuelEconomyForm";
            this.Text = "Fuel Economy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MilesPromptLabel;
        private System.Windows.Forms.Label GallonsPromptLabel;
        private System.Windows.Forms.Label OutputDescriptionLabel;
        private System.Windows.Forms.TextBox MilesTextBox;
        private System.Windows.Forms.TextBox GallonsTextbox;
        private System.Windows.Forms.Label MPG_Label;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

